/**
 * Written by Azul Systems, and released to the public domain,
 * as explained at http://creativecommons.org/publicdomain/zero/1.0/
 */

package org.HdrHistogram.HistogramLogAnalyzer.applicationlayer;

enum PlotFilesMode {
    SAME_CHART,
    SAME_TAB,
    MULTIPLE_TABS
}
