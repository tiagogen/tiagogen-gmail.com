/**
 * Written by Azul Systems, and released to the public domain,
 * as explained at http://creativecommons.org/publicdomain/zero/1.0/
 */

package org.HdrHistogram.HistogramLogAnalyzer.applicationlayer;

public final class Version {
    public static final String version="1.0.4-SNAPSHOT";
    public static final String build_time="29-mar-2020 19:32:06 UTC";
}
